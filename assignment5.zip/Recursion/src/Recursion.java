//1.	Why is the Stack so important to implement recursion? When a recursive call is made what all is pushed on the stack? What will happen if there is no exit condition in a recursive function?
//2.	Calculate the factorial of a number using recursion.
//3.	Print the Fibonacci series using recursion.
//4.	Sort an array using a recursive algorithm.
//5.	Solve the Towers of Hanoi problem using recursion.
//6.	Solve a (n x n) determinant using recursion.
//7.	Generate the Sierpinski's Triangle fractal.
//8.	Solve the eight queen�s problem.
//9.	Write a program to find a sequence of moves of a knight such that each square on the chessboard is visited exactly once. The knight is initially placed in one corner of the chessboard. 
//10.	Input to the program will be a path on the disk. The output will be a list of all files in all the sub-folders recursively.
import java.util.*;
import java.io.*;

public class Recursion {

	// co-ordinates for x and y-cordinates required in knight problem

	public static int factorial(int no) {
		if (no >= 1) {
			return no * factorial(no - 1);
		} else {
			return 1;
		}
	}

	public static int fibonacci(int no) {
		if (no == 0) {
			return 0;
		} else if (no == 1) {
			return 1;
		} else {
			return (fibonacci(no - 1) + fibonacci(no - 2));
		}
	}

	public static void recursiveBubbleSort(int[] arr, int n) {
		if (n == 1) {
			return;
		}
		for (int i = 0; i < n - 1; i++) {
			// comparing with alternate elements
			if (arr[i] > arr[i + 1]) {
				int temp = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = temp;
			}
		}
		// calling function recursively by reducing the size by 1
		recursiveBubbleSort(arr, n - 1);
	}

	public static void towerOfHanoi(int n, char from_rod, char to_rod, char aux_rod)
//excessive recursion 
	{
		if (n == 1) {
			System.out.println("Move disk 1 from rod " + from_rod + " to rod " + to_rod);
			return;
		}
		towerOfHanoi(n - 1, from_rod, aux_rod, to_rod);
		System.out.println("Move disk " + n + " from rod " + from_rod + " to rod " + to_rod);
		towerOfHanoi(n - 1, aux_rod, to_rod, from_rod);
	}

	static void getCofactor(int mat[][], int temp[][], int p, int q, int n) {
		int i = 0, j = 0;

// Looping for each element of
// the matrix
		for (int row = 0; row < n; row++) {
			for (int col = 0; col < n; col++) {
// Copying into temporary matrix
// only those element which are
// not in given row and column
				if (row != p && col != q) {
					temp[i][j++] = mat[row][col];
// Row is filled, so increase
// row index and reset col
// index
					if (j == n - 1) {
						j = 0;
						i++;
					}
				}
			}
		}
	}

	static int determinantOfMatrix(int mat[][], int n) {
		int D = 0; // Initialize result

		// Base case : if matrix contains single
		// element
		if (n == 1)
			return mat[0][0];

		// To store cofactors
		int temp[][] = new int[n][n];

		// To store sign multiplier
		int sign = 1;

		// Iterate for each element of first row
		for (int f = 0; f < n; f++) {
			// Getting Cofactor of mat[0][f]
			getCofactor(mat, temp, 0, f, n);
			D += sign * mat[0][f] * determinantOfMatrix(temp, n - 1);

			// terms are to be added with
			// alternate sign
			sign = -sign;
		}

		return D;
	}

	public static void main(String[] args) {
		Scanner sobj = new Scanner(System.in);
		System.out.println(factorial(6));
		System.out.println("enter the number up to which you want to calculate fibonacci series");
		int no = sobj.nextInt();
		System.out.print(0 + " ");
		for (int i = 1; i <= no - 1; i++) {
			System.out.print(fibonacci(i) + " ");
		}

		System.out.println("*********sorting using recursion**********");

		int arr[] = { 100, 90, 80, 70, 60, 50, 40, 30 };
		recursiveBubbleSort(arr, arr.length);
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
		System.out.println("******Tower of Hanoi*************");
		System.out.println("enter the number of disc you want to have");
		int no3 = sobj.nextInt();
		towerOfHanoi(no3, 'S', 'D', 'I');
		System.out.println("enter the number of rows");
		int row = sobj.nextInt();
		System.out.println("enter the number of columns");
		int col = sobj.nextInt();
		int A[][] = new int[row][col];
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				System.out.print("A[" + i + "][" + j + "]: ");
				A[i][j] = sobj.nextInt();

			}
			System.out.println(determinantOfMatrix(A, row));
		}
		System.out.println("******8queens******");
		eightqueens.solve8Q();
		String path = "C:\\Users\\waghhkau\\Desktop\\";

		// object
		File maindir = new File(path);

		if (maindir.exists() && maindir.isDirectory()) {
			// array for files and sub-directories
			// of directory pointed by maindir
			File arr1[] = maindir.listFiles();

			System.out.println("Files from main directory : " + maindir);
			System.out.println("**********************************************");

			// Calling recursive method

			RecursivePrintFile.RecursivePrint(arr1, row, col);
		}
		System.out.println("*******Knight route*********");

		knightproblem.knightproblem();
		boolean flag = true;
		SierpinskiTriangle sobj1 = new SierpinskiTriangle();
		sobj1.triangle(5, 15, 5, flag);

		flag = false;
		sobj1.triangle(25, 15, 5, flag);
		sobj1.triangle(15, 15, 5, flag);
		System.out.println("**********Triangle***********");
		sobj1.displaying();
	}
}
