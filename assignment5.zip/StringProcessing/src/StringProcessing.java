//1.	Write a program that inputs a string and counts the number of individual and total vowels present in the string.
//2.	Write a program that inputs a string and prints out all the characters that are not digits and not alphabets (except vowels).
//3.	Write a program that can tell if an inputted string is a palindrome or not.
//4.	Write a function which accepts a string and returns a string that is derived of all its whitespace
//Write a function that accepts a string and returns a string in which characters are converted to uppercase. 
//6.	Write a program that takes two strings as input, say str1 and str2. List down the occurrences of str2 in str1.
//7.	Write functions that will trim a string left and trim a string right.
//
//
//8.	Convert a user inputted string to uppercase by using java APIs.
//9.	A program takes two strings as input, say str1 and str2. List down the occurrences of str2 in str1, using java APIs.
//10.	Trim a string left & right using java APIs.
//11.	There is a funciton that returns a 16 character string. It needs to called between 5K-10K times and the resutant strings need to be concatted. Which is the best way to do this in java? Why?




import java.util.*;
import java.util.regex.*;

public class StringProcessing {

	private final static Pattern LTRIM = Pattern.compile("^\\s+");
	private final static Pattern RTRIM = Pattern.compile("\\s+$");

	public static void Vowelscalculation(String str) {
		int length = 0;
		int vowels = 0;
		char[] strCharArray = str.toCharArray();
		for (char c : strCharArray) {
			if (c != ' ') {
				length++;
			}
			if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'A' || c == 'E' || c == 'I' || c == 'O'
					|| c == 'U') {
				vowels++;
			}
		}

		System.out.println("The number of characters in string are " + length + "and vowels are " + vowels);
	}

	public static String printingspecificcharacters(String str) {
		StringBuilder st = new StringBuilder();
		char[] strCharArray = str.toCharArray();
		for (char c : strCharArray) {
			if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'A' || c == 'E' || c == 'I' || c == 'O'
					|| c == 'U' || c == '!' || c == '@' || c == '#' || c == '$' || c == '%' || c == '^' || c == '&'
					|| c == '*' || c == '(' || c == ')' || c == '-' || c == '_' || c == '+' || c == '=' || c == '@'
					|| c == '{' || c == '}' || c == '[' || c == ']' || c == '\\' || c == '|' || c == ';' || c == ':'
					|| c == '?' || c == '>' || c == '<' || c == '.' || c == ',' || c == '/') {
				st.append(c);
			}
		}
		System.out.println(st);
		String singleString = st.toString();
		return singleString;
	}

	public static boolean palindrome(String str) {
		int start = 0;
		int end = str.length() - 1;
		while (start <= end) {
			if (str.charAt(start) == str.charAt(end)) {
				start++;
				end--;
			} else {
				return false;
			}
		}
		return true;
	}

	public static String WhiteSpaceRemoved(String str) {
		StringBuilder str1 = new StringBuilder();
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) != ' ') {
				str1.append(str.charAt(i));
			}
		}
		String singleString = str1.toString();
		return singleString;
	}

	public static String Uppercase(String str) {
		StringBuilder str2 = new StringBuilder();
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) >= 'a' && str.charAt(i) <= 'z') {
				str2.append((char) (int) (str.charAt(i) - 32));
			} else {
				str2.append(str.charAt(i));
			}
		}
		String singleString = str2.toString();
		return singleString;
	}

	public static String ltrim(String s) {
		return LTRIM.matcher(s).replaceAll("");
	}

	public static String rtrim(String s) {
		return RTRIM.matcher(s).replaceAll("");
	}

	public static boolean StringContains(String str1, String str2) {

		if (str1.contains(str2)) {

			return true;

		}
		return false;

	}

	public static String hello() {
		return "Nvu7xxwiYyWMuP4r";
	}

	public static int frequency(String first, String second) {
		int icnt = 0;
		int j = 0;
		int no1 = first.length();
		int no2 = second.length();
		for (int i = 0; i <= no1 - no2; i++) {
			for (j = 0; j < no2; j++) {
				if (first.charAt(i + j) != second.charAt(j)) {
					break;
				}

			}
			if (j == no2) {
				icnt++;
				j = 0;
			}
		}
		return icnt;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sobj = new Scanner(System.in);
		System.out.println("Enter the string of which you want to calculate length and vowels");
		String str = sobj.nextLine();
		Vowelscalculation(str);
		System.out.println("**********Palindrome***********");
		System.out.println("Enter the string to check wether it is palindrome or not");
		String str2 = sobj.nextLine();
		if (palindrome(str2)) {
			System.out.println("It is palindrome");
		} else {
			System.out.println("It is not a palindrome");
		}

		System.out.println("Enter the string of which of which you want to erase whitespace");
		String str3 = sobj.nextLine();
		String result = WhiteSpaceRemoved(str3);
		System.out.println(result);

		System.out.println("Enter the string you want to convert in uppercase");
		String str4 = sobj.nextLine();
		System.out.println("using API");
		System.out.println(str4.toUpperCase());
		System.out.println("without using api");
		String result1 = Uppercase(str4);
		System.out.println(result1);
		String string = "    kaustubh   ";
		System.out.println(string.trim()); //using api
		System.out.println(string);     //original string
		System.out.println("performing left trim");
		System.out.println((ltrim(string)));
		System.out.println("performing right trim");
		System.out.println(rtrim(string));
		String st1 = "abcabc";
		String st2 = "abc";
		if (StringContains(st1, st2)) {
			System.out.println("present");
		} else {
			System.out.println("not present");
		}
		String result10 = "";
		String s = ";.,/?Abcd@#$%^&*()_-+={}[]hello2345";
		System.out.println(printingspecificcharacters(s));
//in java we can use + to concat string.hello()returns 16 characters string.we call it for 10 times
//each time the result string will be concatenated with string returned from hello.
//final output will be the concatenated string.
//we can call it many times.
		for (int i = 0; i < 10; i++) {
			result10 = result10 + (hello());
		}
		System.out.println(result10);
		System.out.println("enter the first string");
		String first = sobj.nextLine();
		System.out.println("enter the second string");
		String second = sobj.nextLine();
		int frequency = frequency(first, second);
		System.out.println(second + " has occured " + frequency + " times in " + "first string");
	}
}